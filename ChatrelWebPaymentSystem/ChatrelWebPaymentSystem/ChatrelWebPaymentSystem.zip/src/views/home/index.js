import React from 'react';
import Home from './home.js';
export default function CoverHome() {
  return (
    <>
      <Home />
    </>
  );
}
