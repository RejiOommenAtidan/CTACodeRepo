import React from 'react';
import Test from './test.js';
export default function CoverHome() {
  return (
    <>
      <Test />
    </>
  );
}
