import React from 'react';

import PageLoginBasic1 from '../../example-components/PageLoginBasic/PageLoginBasic1';
export default function PageLoginBasic() {
  return (
    <>
      <PageLoginBasic1 />
    </>
  );
}
