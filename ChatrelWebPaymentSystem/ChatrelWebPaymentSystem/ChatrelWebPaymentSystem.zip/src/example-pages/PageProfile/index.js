import React from 'react';

import PageProfile1 from '../../example-components/PageProfile/PageProfile1';
export default function PageProfile() {
  return (
    <>
      <PageProfile1 />
    </>
  );
}
